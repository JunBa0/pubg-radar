# Sci Chicken

A PUBG pcap playback system that does not hog CPU/GPU, works with version 3.7.33

## Sniff

You need an extra linux server to be the man in the middle

Server running command：
```bash
yum install git;git clone https://github.com/794959818/PUBG-Radar-Onekey.git; chmod +x . /root/PUBG-Radar-Onekey/update.sh;. /root/PUBG-Radar-Onekey/update.sh
```

## Translation

回车后开始安装  Enter after installation

记住了吗？任意键继续  Remember? Any key continues

请输入你的内网ip   Please enter your private Network ip

搭建完成 Build up


## Link

Local computer using SSTAP connection

Watching address  serverIP:20086/


Restart PUBG-Radar command

```bash
cd /root/PUBG-Radar-Onekey&&./restart.sh
